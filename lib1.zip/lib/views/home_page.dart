import 'package:flutter/material.dart';
import 'Faculte/Faculte_page.dart';
import 'Home/ActualHomePage.dart'; // Importe la page qui sera affichée dans l'onglet "Accueil"
import 'Suggestion/Suggestion_page.dart';
import 'Profil/Profil_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _currentIndex = 0; // index de la page actuelle

  // Liste des pages selon ta structure
  // J'utilise le nom ActualHomePage pour éviter le conflit avec cette classe `HomePage`
  final List<Widget> _pages = [
    const ActualHomePage(), // La vraie page d'accueil de l'onglet
    const FacultePage(),
    const SuggestionPage(),
    const ProfilPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // L'AppBar peut afficher un titre différent selon l'onglet
      appBar: AppBar(
        elevation: 0, // pas d'ombre
        backgroundColor: Theme.of(context).colorScheme.primary, // Utilise primary
        title: Text(
          // Une liste simple pour le titre de l'AppBar
          ['Accueil', 'Faculté', 'Suggestions', 'Profil'][_currentIndex],
          style: const TextStyle(
            fontSize: 20, // Taille ajustée pour la lisibilité
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: _pages[_currentIndex], // affiche la page selon l'index
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index; // change de page
          });
        },
        selectedItemColor: Theme.of(context).colorScheme.primary,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Accueil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'Faculté',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.mail),
            label: 'Suggestions',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}