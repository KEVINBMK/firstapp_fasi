import 'package:flutter/material.dart';

class SuggestionPage extends StatelessWidget {
  const SuggestionPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      // On retire le Scaffold/AppBar pour ne garder que le contenu.
      child: Text(
        "Page des Suggestions",
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600),
      ),
    );
  }
}