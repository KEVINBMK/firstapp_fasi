import 'package:flutter/material.dart';

class FacultePage extends StatelessWidget {
  const FacultePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        "Page de Faculté",
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600),
      ),
    );
  }
}